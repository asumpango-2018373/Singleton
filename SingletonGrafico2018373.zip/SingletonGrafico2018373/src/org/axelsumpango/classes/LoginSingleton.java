/*
    Paso 1: Crear un constructor de la clase (public) private.
    Paso 2: Declarar una variable privada y estatica del formulario 
            que se quiere utilizar (JFrame).
    Paso 3: Agregar la libreria.
    Paso 4: Creamos un método para la instancia del objeto.
    Paso 5: Agregar el paquete Login con su clase.
*/
package org.axelsumpango.classes;

import javax.swing.JFrame;
import org.axelsumpango.system.Login;


public class LoginSingleton {
    private static JFrame log;
    
    private LoginSingleton(){
        
    }
    
    public static JFrame getInstance(){
        if(log == null)
            log = new Login();
        return log;
    }
}
